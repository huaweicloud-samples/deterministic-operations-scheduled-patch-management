# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateVpcCondition:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'host_id_list': 'list[str]',
        'vpc_list': 'list[VpcAndSubNet]'
    }

    attribute_map = {
        'host_id_list': 'host_id_list',
        'vpc_list': 'vpc_list'
    }

    def __init__(self, host_id_list=None, vpc_list=None):
        r"""CreateVpcCondition

        The model defined in huaweicloud sdk

        :param host_id_list: **参数解释** 主机id列表 **约束限制**: 不涉及 **取值范围** 字符长度1-256位 **默认取值**: 不涉及 
        :type host_id_list: list[str]
        :param vpc_list: **参数解释** vpc列表 **约束限制**: 不涉及 **取值范围** 字符长度1-256位 **默认取值**: 不涉及 
        :type vpc_list: list[:class:`huaweicloudsdkhss.v5.VpcAndSubNet`]
        """
        
        

        self._host_id_list = None
        self._vpc_list = None
        self.discriminator = None

        if host_id_list is not None:
            self.host_id_list = host_id_list
        if vpc_list is not None:
            self.vpc_list = vpc_list

    @property
    def host_id_list(self):
        r"""Gets the host_id_list of this CreateVpcCondition.

        **参数解释** 主机id列表 **约束限制**: 不涉及 **取值范围** 字符长度1-256位 **默认取值**: 不涉及 

        :return: The host_id_list of this CreateVpcCondition.
        :rtype: list[str]
        """
        return self._host_id_list

    @host_id_list.setter
    def host_id_list(self, host_id_list):
        r"""Sets the host_id_list of this CreateVpcCondition.

        **参数解释** 主机id列表 **约束限制**: 不涉及 **取值范围** 字符长度1-256位 **默认取值**: 不涉及 

        :param host_id_list: The host_id_list of this CreateVpcCondition.
        :type host_id_list: list[str]
        """
        self._host_id_list = host_id_list

    @property
    def vpc_list(self):
        r"""Gets the vpc_list of this CreateVpcCondition.

        **参数解释** vpc列表 **约束限制**: 不涉及 **取值范围** 字符长度1-256位 **默认取值**: 不涉及 

        :return: The vpc_list of this CreateVpcCondition.
        :rtype: list[:class:`huaweicloudsdkhss.v5.VpcAndSubNet`]
        """
        return self._vpc_list

    @vpc_list.setter
    def vpc_list(self, vpc_list):
        r"""Sets the vpc_list of this CreateVpcCondition.

        **参数解释** vpc列表 **约束限制**: 不涉及 **取值范围** 字符长度1-256位 **默认取值**: 不涉及 

        :param vpc_list: The vpc_list of this CreateVpcCondition.
        :type vpc_list: list[:class:`huaweicloudsdkhss.v5.VpcAndSubNet`]
        """
        self._vpc_list = vpc_list

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateVpcCondition):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class AiPolicyList:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'policy_id': 'str',
        'policy_name': 'str',
        'enabled': 'bool'
    }

    attribute_map = {
        'policy_id': 'policy_id',
        'policy_name': 'policy_name',
        'enabled': 'enabled'
    }

    def __init__(self, policy_id=None, policy_name=None, enabled=None):
        r"""AiPolicyList

        The model defined in huaweicloud sdk

        :param policy_id: **参数解释**: 策略ID **取值范围**: 字符长度1-20位 
        :type policy_id: str
        :param policy_name: **参数解释**: 策略名称 **取值范围**： - 0: 意图行为一致性检测 - 1: 命令执行控制 - 2: 文件访问控制 - 3: 敏感信息检测 - 4: 角色限定 
        :type policy_name: str
        :param enabled: **参数解释**: 是否启用 **取值范围**: - false：否 - true：是 
        :type enabled: bool
        """
        
        

        self._policy_id = None
        self._policy_name = None
        self._enabled = None
        self.discriminator = None

        if policy_id is not None:
            self.policy_id = policy_id
        if policy_name is not None:
            self.policy_name = policy_name
        if enabled is not None:
            self.enabled = enabled

    @property
    def policy_id(self):
        r"""Gets the policy_id of this AiPolicyList.

        **参数解释**: 策略ID **取值范围**: 字符长度1-20位 

        :return: The policy_id of this AiPolicyList.
        :rtype: str
        """
        return self._policy_id

    @policy_id.setter
    def policy_id(self, policy_id):
        r"""Sets the policy_id of this AiPolicyList.

        **参数解释**: 策略ID **取值范围**: 字符长度1-20位 

        :param policy_id: The policy_id of this AiPolicyList.
        :type policy_id: str
        """
        self._policy_id = policy_id

    @property
    def policy_name(self):
        r"""Gets the policy_name of this AiPolicyList.

        **参数解释**: 策略名称 **取值范围**： - 0: 意图行为一致性检测 - 1: 命令执行控制 - 2: 文件访问控制 - 3: 敏感信息检测 - 4: 角色限定 

        :return: The policy_name of this AiPolicyList.
        :rtype: str
        """
        return self._policy_name

    @policy_name.setter
    def policy_name(self, policy_name):
        r"""Sets the policy_name of this AiPolicyList.

        **参数解释**: 策略名称 **取值范围**： - 0: 意图行为一致性检测 - 1: 命令执行控制 - 2: 文件访问控制 - 3: 敏感信息检测 - 4: 角色限定 

        :param policy_name: The policy_name of this AiPolicyList.
        :type policy_name: str
        """
        self._policy_name = policy_name

    @property
    def enabled(self):
        r"""Gets the enabled of this AiPolicyList.

        **参数解释**: 是否启用 **取值范围**: - false：否 - true：是 

        :return: The enabled of this AiPolicyList.
        :rtype: bool
        """
        return self._enabled

    @enabled.setter
    def enabled(self, enabled):
        r"""Sets the enabled of this AiPolicyList.

        **参数解释**: 是否启用 **取值范围**: - false：否 - true：是 

        :param enabled: The enabled of this AiPolicyList.
        :type enabled: bool
        """
        self._enabled = enabled

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AiPolicyList):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

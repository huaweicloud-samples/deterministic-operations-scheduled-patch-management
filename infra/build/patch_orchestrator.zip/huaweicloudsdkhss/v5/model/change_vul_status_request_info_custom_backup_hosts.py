# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ChangeVulStatusRequestInfoCustomBackupHosts:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'host_id': 'str',
        'vault_id': 'str',
        'backup_name': 'str'
    }

    attribute_map = {
        'host_id': 'host_id',
        'vault_id': 'vault_id',
        'backup_name': 'backup_name'
    }

    def __init__(self, host_id=None, vault_id=None, backup_name=None):
        r"""ChangeVulStatusRequestInfoCustomBackupHosts

        The model defined in huaweicloud sdk

        :param host_id: **参数解释**: 主机id **约束限制**: 不涉及 **取值范围**: 字符长度1-128位 **默认取值**: 不涉及 
        :type host_id: str
        :param vault_id: **参数解释**: 存储库id **约束限制**: 不涉及 **取值范围**: 字符长度1-128位 **默认取值**: 不涉及 
        :type vault_id: str
        :param backup_name: **参数解释**: 备份名称 **约束限制**: 不涉及 **取值范围**: 字符长度1-64位 **默认取值**: 不涉及 
        :type backup_name: str
        """
        
        

        self._host_id = None
        self._vault_id = None
        self._backup_name = None
        self.discriminator = None

        if host_id is not None:
            self.host_id = host_id
        if vault_id is not None:
            self.vault_id = vault_id
        if backup_name is not None:
            self.backup_name = backup_name

    @property
    def host_id(self):
        r"""Gets the host_id of this ChangeVulStatusRequestInfoCustomBackupHosts.

        **参数解释**: 主机id **约束限制**: 不涉及 **取值范围**: 字符长度1-128位 **默认取值**: 不涉及 

        :return: The host_id of this ChangeVulStatusRequestInfoCustomBackupHosts.
        :rtype: str
        """
        return self._host_id

    @host_id.setter
    def host_id(self, host_id):
        r"""Sets the host_id of this ChangeVulStatusRequestInfoCustomBackupHosts.

        **参数解释**: 主机id **约束限制**: 不涉及 **取值范围**: 字符长度1-128位 **默认取值**: 不涉及 

        :param host_id: The host_id of this ChangeVulStatusRequestInfoCustomBackupHosts.
        :type host_id: str
        """
        self._host_id = host_id

    @property
    def vault_id(self):
        r"""Gets the vault_id of this ChangeVulStatusRequestInfoCustomBackupHosts.

        **参数解释**: 存储库id **约束限制**: 不涉及 **取值范围**: 字符长度1-128位 **默认取值**: 不涉及 

        :return: The vault_id of this ChangeVulStatusRequestInfoCustomBackupHosts.
        :rtype: str
        """
        return self._vault_id

    @vault_id.setter
    def vault_id(self, vault_id):
        r"""Sets the vault_id of this ChangeVulStatusRequestInfoCustomBackupHosts.

        **参数解释**: 存储库id **约束限制**: 不涉及 **取值范围**: 字符长度1-128位 **默认取值**: 不涉及 

        :param vault_id: The vault_id of this ChangeVulStatusRequestInfoCustomBackupHosts.
        :type vault_id: str
        """
        self._vault_id = vault_id

    @property
    def backup_name(self):
        r"""Gets the backup_name of this ChangeVulStatusRequestInfoCustomBackupHosts.

        **参数解释**: 备份名称 **约束限制**: 不涉及 **取值范围**: 字符长度1-64位 **默认取值**: 不涉及 

        :return: The backup_name of this ChangeVulStatusRequestInfoCustomBackupHosts.
        :rtype: str
        """
        return self._backup_name

    @backup_name.setter
    def backup_name(self, backup_name):
        r"""Sets the backup_name of this ChangeVulStatusRequestInfoCustomBackupHosts.

        **参数解释**: 备份名称 **约束限制**: 不涉及 **取值范围**: 字符长度1-64位 **默认取值**: 不涉及 

        :param backup_name: The backup_name of this ChangeVulStatusRequestInfoCustomBackupHosts.
        :type backup_name: str
        """
        self._backup_name = backup_name

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ChangeVulStatusRequestInfoCustomBackupHosts):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other

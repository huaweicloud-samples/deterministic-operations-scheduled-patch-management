# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class BatchUpdateDaemonsetRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'data_list': 'list[UpdateDaemonsetInfo]'
    }

    attribute_map = {
        'data_list': 'data_list'
    }

    def __init__(self, data_list=None):
        r"""BatchUpdateDaemonsetRequestBody

        The model defined in huaweicloud sdk

        :param data_list: 批量升级列表
        :type data_list: list[:class:`huaweicloudsdkhss.v5.UpdateDaemonsetInfo`]
        """
        
        

        self._data_list = None
        self.discriminator = None

        self.data_list = data_list

    @property
    def data_list(self):
        r"""Gets the data_list of this BatchUpdateDaemonsetRequestBody.

        批量升级列表

        :return: The data_list of this BatchUpdateDaemonsetRequestBody.
        :rtype: list[:class:`huaweicloudsdkhss.v5.UpdateDaemonsetInfo`]
        """
        return self._data_list

    @data_list.setter
    def data_list(self, data_list):
        r"""Sets the data_list of this BatchUpdateDaemonsetRequestBody.

        批量升级列表

        :param data_list: The data_list of this BatchUpdateDaemonsetRequestBody.
        :type data_list: list[:class:`huaweicloudsdkhss.v5.UpdateDaemonsetInfo`]
        """
        self._data_list = data_list

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, BatchUpdateDaemonsetRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
